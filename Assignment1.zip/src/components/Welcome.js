function Welcome() {
  return <div>
    Welcome
  </div>
}

export default Welcome;